==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Paquete de aplicación para Linux 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Reservados todos los derechos.

==============================================================================
  Este documento se proporciona "tal cual" sin garantía de ninguna clase. 
  IBM no proporciona garantías, ni expresas ni implícitas,
  incluidas, pero sin limitarse a ellas, las garantías implícitas de
  idoneidad para un fin determinado y de comerciabilidad con respecto
  a la información contenida en este documento. 
  Al proporcionar este documento, IBM no le otorga derechos sobre patentes o
  copyrights. 

===============================================================================

  Este paquete forma parte del producto 5733XJ1 IBM i Access Client Solutions.

  Puede utilizar IBM i Access Client Solutions para conectar con cualquier
  release soportado de IBM i.

  Este paquete contiene funciones que sólo están disponibles en los sistemas
  operativos Linux. Está basado en el producto 7.1 IBM i Access para Linux, pero no
  contiene todas sus funciones.

  La versión de 64 bits de este paquete incluye un controlador ODBC de 64 bits,
  compatible con la versión 2.2.13 (y posteriores) de los paquetes del administrador
  de controladores unixODBC.
  Si su sistema no tiene unixODBC versión 2.2.13 o posterior, el
  controlador ODBC contenido en este paquete no funcionará correctamente y
  puede producir la detención anómala de la aplicación.
  Para localizar el paquete apropiado para sus necesidades, extraiga el archivo
  .zip y encuentre el directorio apropiado para la arquitectura de su estación de
  trabajo. Este directorio habitualmente es 'x86_64Bit' para máquinas de 64 bits o
 'i386_32Bit' para máquinas de 32 bits. Este directorio contendrá instaladores
  .deb y .rpm. El archivo .rpm se puede utilizar para instalar en distribuciones
  basadas en RPM de Linux, tales como RedHat, Fedora o SuSE. El archivo .deb se
  puede utilizar en distribuciones basadas en Debian, tales como Ubuntu. 
  
  Para instalar este paquete, puede utilizar el gestor de paquetes apropiado para su
  distribución Linux.
  Esto incluye zypper, yum, apt-get, rpm o dpkg. 
  La instalación típica mediante mandatos dpkg o rpm se puede realizar con el argumento
  '-i'.
  Ejemplos:
       dpkg -i <nombre_archivo>.deb
       rpm -i <nombre_archivo>.rpm

  Para obtener más información sobre IBM i Access Client Solutions, consulte:
	http://www-03.ibm.com/systems/power/software/i/access/index.html




   [FIN DEL DOCUMENTO]
