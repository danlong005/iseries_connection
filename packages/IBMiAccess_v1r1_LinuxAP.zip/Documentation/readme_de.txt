==============================================================================

            5733XJ1 IBM i Access Client Solutions -
              Linux Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2013. Alle Rechte vorbehalten.

==============================================================================
  IBM übernimmt keine Haftung für das vorliegende Dokument. Mit der
  Auslieferung dieses Dokuments ist keine Lizenzierung von Patenten
  oder Urheberrechten verbunden.

===============================================================================

  Dieses Paket ist Teil des Produkts IBM i Access Client Solutions (5733XJ1). 

  Sie können mit IBM i Access Client Solutions eine Verbindung zu allen
  unterstützten IBM i-Releases herstellen.

  Dieses Paket enthält Funktionen, die nur unter Linux-Betriebssystemen
  verfügbar sind. Das Produkt basiert auf IBM i Access for Linux 7.1,
  enthält jedoch nicht alle Features.

  Die 64-Bit-Version dieses Paket enthält einen ODBC-Treiber mit umfassender
  64-Bit-Unterstützung, der mit Version 2.2.13 (und höher) der unixODBC-
  Treibermanagerpakete kompatibel ist. Wenn auf Ihrem System unixODBC
  Version 2.2.13 oder höher nicht installiert ist, arbeitet der in diesem
  Paket enthaltene ODBC-Treiber nicht ordnungsgemäß. Dies kann zu einem
  Absturz der Anwendung führen.

  Um das für Ihre Anforderungen geeignete Paket zu suchen, extrahieren Sie
  die .zip-Datei und suchen nach dem Verzeichnis für die Architektur Ihrer
  Workstation. In der Regel ist dies 'x86_64Bit' für 64-Bit-Systeme oder
  'i386_32Bit' für 32-Bit-Systeme. Dieses Verzeichnis enthält sowohl
  .deb- als auch .rpm-Installationsprogramme. Mit der .rpm-Datei können
  RPM-basierte Linux-Distributionen wie RedHat, Fedora oder SuSE installiert
  werden. Die .deb-Datei kann für Debian-basierte Distributionen wie Ubuntu
  verwendet werden. 
  
  Zur Installation dieses Pakets können Sie den für Ihre Linux-Distribution
  geeigneten Paketmanager verwenden. Dazu gehören zypper, yum, apt-get, rpm und dpkg. 
  Eine Standardinstallation mit den Befehlen dpkg oder rpm kann mit dem Argument '-i'
  erfolgen. Beispiele:
       dpkg -i <dateiname>.deb
       rpm -i <dateiname>.rpm

  Weitere Informationen über IBM i Access Client Solutions finden Sie unter:
	http://www-03.ibm.com/systems/power/software/i/access/index.html




   [ENDE DES DOKUMENTS]
