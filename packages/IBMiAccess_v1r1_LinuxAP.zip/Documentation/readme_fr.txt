==============================================================================

            5733XJ1 IBM i Access Client Solutions - Module d'application Linux 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  All rights reserved. 

==============================================================================
  Ce document vous est concédé "en l'état" sans garantie d'aucune sorte.  IBM décline toute responsabilité, expresse ou implicite,
    relative aux informations contenues dans le présent document,
    y compris en ce qui concerne les garanties de qualité marchande ou
    d'adaptation à vos besoins. Par la remise de ce document, IBM n'accorde aucune licence sur quelque
    brevet ou copyright que ce soit. 

===============================================================================

  Ce module fait partie du produit IBM i Access Client Solutions (5733XJ1). 

  Vous pouvez utiliser IBM i Access Client Solutions pour vous connecter à n'importe quelle édition IBM i
  prise en charge.

  Ce module contient des fonctions disponibles uniquement sur les systèmes d'exploitation
  Linux. Il est basé sur le produit IBM i Access for Linux 7.1, mais il ne contient pas tous
  les dispositifs de celui-ci.

  La version 64 bits de ce module comporte un pilote ODBC 64 bits complet, compatible avec la version
  2.2.13 (et les versions suivantes) des modules de gestionnaire de pilotes unixODBC. Si votre
  système n'est pas doté de la version 2.2.13 ou d'une version suivante de unixODBC, le pilote ODBC contenu
  dans ce module ne fonctionnera pas correctement, et l'application peut tomber en panne.

  Pour localiser le module adapté à vos besoins, procédez à l'extraction du fichier .zip et recherchez le
  répertoire approprié pour l'architecture de votre poste de travail. Il s'agit généralement de
  'x86_64Bit' pour les machines 64 bits ou de 'i386_32Bit' pour les machines 32 bits. Ce répertoire
  contient les programmes d'installation .deb et .rpm. Le fichier .rpm peut être utilisé pour effectuer
  une installation sur des distributions RPM de Linux, telles que RedHat, Fedora ou SuSE. Le fichier .deb
  peut être utilisé sur des distributions Debian, telles que Ubuntu. 
  
  Pour installer ce module, vous pouvez utiliser le gestionnaire de modules approprié pour votre distribution
  Linux. Cela inclut notamment zypper, yum, apt-get, rpm ou dpkg. 
  Une installation normale à l'aide des commandes dpkg ou rpm peut être effectuée en utilisant l'argument '-i'.
  Exemples :
       dpkg -i <nom_fichier>.deb
       rpm -i <nom_fichier>.rpm

  Pour plus d'informations sur IBM i Access Client Solutions, consultez :
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[FIN DE DOCUMENT]
