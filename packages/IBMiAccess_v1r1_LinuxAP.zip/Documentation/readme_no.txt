==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2013.  All rights reserved. 

==============================================================================
  Dette dokumentet leveres i den stand det befinner seg ("as is"),
  uten garantier av noe slag.  IBM gir ingen garantier, uttrykt
  eller underforstått, inkludert, uten begrensning, underforståtte
  garantier vedrørende anvendelse for et bestemt formål eller
  salgbarhet i forbindelse med informasjonen i dette dokumentet.   Ved å levere dette dokumentet tildeler IBM ingen lisenser til
  eventuelle patenter eller opphavsretter. 

===============================================================================

  Denne pakken er en del av produktet 5733XJ1 IBM i Access Client Solutions.

  Du kan bruke IBM i Access Client Solutions for tilkobling til en støttet IBM i-
  utgave.

  Denne pakken inneholder funksjoner som bare er tilgjengelige på Linux-
  operativsystemer. Den er basert på produktet 7.1 IBM i Access for Linux, men
  inneholder ikke alle funksjonene i det produktet.

  64-bits versjonen av denne pakken inneholder et fullstendig 64-bits ODBC-styreprogram
  som er kompatibelt med versjon 2.2.13 (og nyere) av unixODBC Driver Manager-pakkene. 
  Hvis systemet ikke har unixODBC versjon 2.2.13 eller nyere, vil ODBC-styreprogrammene
  i denne pakken ikke fungere riktig og kan føre til at applikasjoner krasjer.

  Når du skal finne pakken som passer for dine behov, pakker du opp zip-filen og
  finner katalogen for din arbeidsstasjons arkitektur. Dette er vanligvis
  'x86_64Bit' for 64-bits maskiner eller 'i386_32Bit' for 32-bits maskiner. Denne
  katalogen inneholder både deb- og rpm-installerere. rpm-filen kan brukes til å
  installere på RPM-baserte distribusjoner av Linux som RedHat, Fedora og SuSE. 
  deb-filen kan brukes på Debian-baserte distribusjoner som Ubuntu. 
  
  Når du skal installere denne pakken, kan du bruke pakkestyreren som passer for
  din Linux-distribusjon. Dette omfatter zypper, yum, apt-get, rpm og dpkg. 
  En typisk installering med dpkg- eller rpm-kommandoen kan utføres med argumentet '-i'.
  Eksempler:
       dpkg -i <filnavn>.deb
       rpm -i <filnavn>.rpm

  Du finner mer informasjon om IBM i Access Client Solutions her:
	http://www-03.ibm.com/systems/power/software/i/access/index.html




   [SLUTTEN PÅ DOKUMENTET]
