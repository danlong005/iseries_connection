==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2013.  All rights reserved. 

    Dette dokument stilles til rådighed uden nogen form for garantier.
    IBM fraskriver sig ethvert ansvar, både direkte og indirekte, herunder,
    men ikke begrænset til, et produkts salgbarhed eller egnethed til
    et bestemt formål, hvad angår oplysningerne i dette dokument. 

===============================================================================

  Denne pakke er en del af 5733XJ1 IBM i Access Client Solutions-produktet.

  Du kan anvende IBM i Access Client Solutions til at oprette forbindelse til en
  understøttet IBM i release.

  Pakken indeholder funktioner, der kun er tilgængelige på Linux styresystem.
  Det er baseret på 7.1 IBM i Access for Linux produktet, men indeholder ikke
  alle funktionerne.

  64-bit versionen af denne pakke, faciliterer en komplet 64-bit ODBC driver, kompatibel
  med version 2.2.13 (og nyere) unixODBC driver manager-pakker. Hvis dit
  system ikke har unixODBC version 2.2.13 eller nyere, vil ODBC driveren i
  denne pakke ikke fungere korrekt, og det kan resultere i applikationsnedbrud.

  For at finde den pakke der passer til dit behov, udpak .zip filen og find
  det bibliotek, der passer til din arbejdsstations arkitektur. Det er normalt
  'x86_64Bit' for 64bit maskiner eller 'i386_32Bit' for 32bit maskiner. Biblioteket
  indeholder både .deb og .rpm installere. .rpm filen kan anvendes til at installere
  på RPM-baserede distributioner af Linux, så som RedHat, Fedora eller SuSE. .deb filen
  kan bruges på Debian-baserede distributioner som Ubuntu. 
  
  For at installere denne pakke, kan du anvende den pakke-manager, der passer til din Linux-distribution.
  Det omfatter zypper, yum, apt-get, rpm eller dpkg. 
  Typisk kan en installation med dpkg eller rpm kommandoer udføres med '-i' argumentet.
  Eksempler:
       dpkg -i <filnavn>.deb
       rpm -i <filnavn>.rpm

  For yderligere oplysninger om IBM i Access Client Solutions, se:
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[Slut på dokument]
