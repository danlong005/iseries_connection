==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux-sovelluspaketti 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Kaikki oikeudet pidätetään. 

==============================================================================
    IBM julkaisee tämän asiakirjan tiedot "sellaisenaan" ilman mitään
    nimenomaisesti tai konkludenttisesti myönnettyä takuuta, mukaan
    luettuina taloudellista hyödynnettävyyttä, sopivuutta tiettyyn
    tarkoitukseen ja oikeuksien loukkaamattomuutta koskevat
    konkludenttisesti ilmaistut takuut. Tämän asiakirjan hankinta
    ei anna mitään lisenssiä mihinkään patentteihin tai
    tekijänoikeuksiin. 

===============================================================================

  Tämä paketti on osa tuotetta 5733XJ1 IBM i Access Client Solutions.

  IBM i Access Client Solutions -ohjelman avulla voit muodostaa yhteyden mihin tahansa tuettuun IBM i -versioon.

  Tämä paketti sisältää toimintoja, jotka ovat käytettävissä vain Linux-käyttöjärjestelmissä.
  Paketti perustuu 7.1 IBM i Access for Linux -tuotteeseen, mutta se ei sisällä kaikkia samoja
  ominaisuuksia.
  Paketin 64-bittinen versio sisältää täyden 64-bittisen ODBC-ohjaintiedoston, joka tukee
  unixODBC-ajurihallinnan pakettiversiota 2.2.13 sekä sitä uudempia versioita. Jos
  järjestelmässäsi ei ole vähintään unixODBC-versiota 2.2.13, paketin sisältämä ODBC-
  ohjain ei toimi oikein. Seurauksena voi olla sovelluksen kaatuminen.

  Voit paikantaa tarpeisiisi sopivan paketin purkamalla .zip-tiedoston ja
  etsimällä oman työasemasi arkkitehtuurille sopivan hakemiston. Se on yleensä
  'x86_64Bit' 64-bittisille tietokoneille ja 'i386_32Bit' 32-bittisille. Tässä hakemistossa
  on sekä .deb- että .rpm-asennusohjelmat. Näistä .rpm on tarkoitettu asennettavaksi
  RPM-pohjaisiin Linux-jakeluihin, kuten RedHat, Fedora tai SuSE. Tiedosto jonka pääte on
 .deb soveltuu Debian-pohjaisiin jakeluihin, kuten Ubuntuun. 
  
  Voit asentaa paketin oman Linux-jakelusi pakettienhallintaan
  käytetyllä ohjelmalla. Näitä ovat zypper, yum, apt-get, rpm ja dpkg. 
  Tyypillinen asennus komennoilla dpkg tai rpm tehdään antamalla määre '-i'.
  Esimerkkejä:
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  Lisätietoja IBM i Access Client Solutions -ohjelmistosta on osoitteessa
	http://www-03.ibm.com/systems/power/software/i/access/index.html




   [LOPPU]
