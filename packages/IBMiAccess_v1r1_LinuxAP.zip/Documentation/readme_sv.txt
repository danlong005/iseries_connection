==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  All rights reserved. 

==============================================================================
  Dokumentet levereras i befintligt skick utan några som helst garantier.
  IBM lämnar inga garantier, vare sig uttryckliga eller underförstådda,
  inklusive, men inte begränsat till, underförstådda garantier om
  lämplighet för ett visst syfte eller allmän beskaffenhet vad avser
  informationen i detta dokument. Dokumentet ger ingen licens till
  patent eller upphovsrätt. 

===============================================================================

  paketet ingår i 5733XJ1 IBM i Access Client Solutions-produkten. 

  Du kan använda IBM i Access Client Solutions för att ansluta till alla IBM i-
  versioner som hanteras. 

  Paketet innehåller funktioner som endast är tillgängliga i Linux-system.
  Det baseras på 7.1 IBM i Access for Linux men innehåller inte alla funktioner.

  64-bitarsversionen av paketet innehåller en 64-bitars ODBC-drivrutin, kompatibel
  med version 2.2.13 (och senare) av unixODBC Driver Manager-paket. Om systemet
  inte har unixODBC version 2.2.13 eller senare, fungerar inte ODBC-drivrutinen
  i det här paketet på rätt sätt och kan resultera i programkraschar.

  Packa upp zip-filen och gå till den katalog som gäller för datorn för att
  hitta det paket som passar. Det är vanligen 'x86_64Bit' för 64-bitarsdatorer
  eller 'i386_32Bit' för datorer med 32-bitars operativsystem. Den här katalogen
  innehåller både .deb- och .rpm-installationsprogram. .rpm-filen kan användas
  för installation av RPM-baserade distributioner av Linux, t.ex. RedHat, Fedora
  och SuSE. .deb-filen kan användas för Debian-baserade distributioner som
  Ubuntu. 
  
  Installera paketet med pakethanteraren för Linux-distribution.
  Det innehåller zypper, yum, apt-get, rpm eller dpkg. 
  Standardinstallation med dpkg- eller rpm-kommandon kan göras med
  '-i'-argumentet.
  Exempel:
       dpkg -i <filnamn>.deb
       rpm -i <filnamn>.rpm

  Mer information om IBM i Access Client Solutions finns på:
	 http://www-03.ibm.com/systems/power/software/i/access/index.html



[SLUT PÅ DOKUMENTET]
