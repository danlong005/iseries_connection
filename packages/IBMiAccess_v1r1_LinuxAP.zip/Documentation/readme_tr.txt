==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2013.  Her hakkı saklıdır. 

==============================================================================
     Bu belge, herhangi bir garanti verilmeden "olduğu gibi" sağlanmıştır.  IBM,
    ticarilik ve belirli bir amaca uygunluk için açık veya zımni garantiler de
    dahil, ancak bunlarla sınırlı olmamak üzere tüm garantileri reddeder. Bu
    belgenin düzenlenmesiyle, IBM herhangi bir patent ya da telif hakkı için
    lisans vermiş olmaz. 

===============================================================================

  Bu paket 5733XJ1 IBM i Access Client Solutions ürününün bir parçasıdır.

  IBM i Access Client Solutions ürününü kullanarak, desteklenen herhangi bir IBM i yayın düzeyine bağlanabilirsiniz.

  Bu pakette, yalnızca Linux işletim sistemlerinde kullanılabilen işlevler yer almaktadır.  Paket, 7.1 IBM i Access for Linux ürününü temel almaktadır, ancak bu ürünün tüm özelliklerini içermez. Bu paketin 64 bitlik sürümü, tam donanımlı, unixODBC sürücü yöneticisi paketlerinin 2.2.13 (ve daha yeni) sürümüyle uyumlu bir 64 bitlik ODBC sürücüsü içerir. Sisteminizde unixODBC 2.2.13 ya da daha yeni bir sürüm bulunmuyorsa, bu pakette bulunan ODBC sürücüsü doğru çalışmaz ve uygulama bozukluklarına neden olabilir. Gereksinimlerinizi uygun paketi bulmak için .zip dosyasını çıkarın ve iş istasyonunuzun mimarisine uygun dizini bulun. Bu genellikle 64 bitlik makineler için 'x86_64Bit' ya da 32 bitkik makineler için 'i386_32Bit' olur. Bu dizin hem .deb hem de .rpm kuruluş programlarını içerir. .rpm dosyası RedHat, Fedora ya da SuSE gibi RPM tabanlı dağıtımları kurmak için kullanılabilir. .deb dosyası, Ubuntu gibi Debian tabanlı dağıtımlarda kullanılabilir. 
  
  Bu paketi kurmak için Linux dağıtımınıza uygun paket yöneticisini kullanabilirsiniz. Buna zypper, yum, apt-get, rpm ya da dpkg dahildir. dpkg ya da rpm komutlarına sahip tipik kuruluş, '-i' bağımsız değişkeniyle yapılabilir. Örnekler:
       dpkg -i <dosyaadı>.deb
       rpm -i <dosyaadı>.rpm

  IBM i Access Client Solutions hakkında daha fazla bilgi için bkz.
	http://www-03.ibm.com/systems/power/software/i/access/index.html



[BELGE SONU]
