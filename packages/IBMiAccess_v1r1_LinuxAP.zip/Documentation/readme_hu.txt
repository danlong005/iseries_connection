==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux alkalmazáscsomag 1.1.0

   (c) Copyright IBM Corporation 1996, 2013.  Minden jog fenntartva. 

==============================================================================
  E dokumentum "jelenlegi formájában", bármilyen garancia vállalása nélkül
  kerül közreadásra. A dokumentum információtartalmára vonatkozóan az IBM
  minden kifejezett vagy vélelmezett garancia vállalásától elhatárolódik,
  beleértve, de nem kizárólag, az adott célra alkalmasság és a
  kereskedelmi értékesíthetőség feltételezett garanciáit. E dokumentum
  közreadásával az IBM semmiféle szabadalmához vagy szerzői jogvédelem
  alatt álló tulajdonához nem ad licencet. 

===============================================================================

  A csomag az 5733XJ1 IBM i Access Client Solutions termék része.

  Az IBM i Access Client Solutions segítségével csatlakozhat bármely támogatott IBM i
  kiadáshoz.

  Ez a csomag csak Linux operációs rendszeren elérhető funkciókat tartalmaz.
  A 7.1 változatú IBM i Access for Linux terméken alapul, de nem tartalmazza az összes
  funkcióját.

  A csomag 64 bites változata tartalmaz egy teljesen 64 bites ODBC
illesztőprogramot, amely kompatibilis az unixODBC illesztőprogram-kezelő csomag 2.2.13
(és újabb) változataival. Ha a rendszer nem rendelkezik unixODBC 2.2.13 vagy újabb
változattal, akkor a csomagban található ODBC illesztőprogram nem fog megfelelően
működni, és ez az alkalmazás összeomlását eredményezheti.

  Az igényeinek megfelelő csomag megkereséséhez bontsa ki a .zip fájlt, és keresse meg a
munkaállomás architektúrájának megfelelő könyvtárat. Ez általában az 'x86_64Bit' a 64
bites számítógépek és az 'i386_32Bit' a 32 bites számítógépek esetében. A könyvtár
tartalmazza a .deb és az .rpm telepítőket is. Az .rpm fájl segítségével RPM alapú
Linux disztribúciókon telepíthető, mint a RedHat, Fedora vagy SuSE. A .deb fájl Debian
alapú disztribúciókon használható, mint például az Ubuntu. 
  
  A csomag telepítéséhez használhatja a Linux disztribúcióhoz való csomagkezelőt. Ez
magában foglalja a következőket: zypper, yum, apt-get, rpm vagy dpkg. 
  A tipikus telepítés dpkg vagy rpm paranccsal a '-i' argumentummal hajtható végre.
  Példák:
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  További információkért az IBM i Access Client Solutions termékkel kapcsolatban,
teintse meg a következőt: http://www-03.ibm.com/systems/power/software/i/access/index.html



[Dokumentum vége]
