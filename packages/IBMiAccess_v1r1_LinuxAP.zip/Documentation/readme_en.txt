==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Linux Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2013.  All rights reserved. 

==============================================================================
  This document is provided "as is" without warranty of any kind.  IBM disclaims 
  all warranties, whether expressed or implied, including without limitation, the
  implied warranties of fitness for a particular purpose and merchantability
  with respect to the information in this document. By furnishing this document,
  IBM grants no licenses to any patents or copyrights. 

===============================================================================

  This package is part of the 5733XJ1 IBM i Access Client Solutions product.

  You can use IBM i Access Client Solutions to connect to any supported IBM i
  release.

  This package contains functions that are only available on Linux operating 
  systems.  It is based on the 7.1 IBM i Access for Linux product but does not 
  contain all of the features.
  
  The 64-bit version of this package features a full 64-bit ODBC driver, compatible
  with version 2.2.13 (and newer) of the unixODBC driver manager packages. If your
  system does not have unixODBC version 2.2.13 or newer, the ODBC driver contained
  in this package will not function correctly and may result in application crashes.
  
  To locate the package suitable for your needs, extract the .zip file and find the
  directory appropriate for your workstation's architecture. This is usually 
  'x86_64Bit' for 64bit machines or 'i386_32Bit' for 32bit machines. This directory
  will contain both .deb and .rpm installers. The .rpm file can be used to install
  on RPM-based distributions of Linux such as RedHat, Fedora, or SuSE. The .deb file 
  can be used on Debian-based distributions like Ubuntu. 
  
  To install this package, you can use the package manager suitable for your Linux
  distribution. This includes zypper, yum, apt-get, rpm, or dpkg. 
  Typical installation with dpkg or rpm commands can be done with the '-i' argument.
  Examples:
       dpkg -i <filename>.deb
       rpm -i <filename>.rpm

  For additional information about IBM i Access Client Solutions, see:
	http://www-03.ibm.com/systems/power/software/i/access/index.html
  
  
    
[END OF DOCUMENT]
